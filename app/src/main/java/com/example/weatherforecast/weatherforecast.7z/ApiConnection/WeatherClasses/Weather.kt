package com.example.weatherforecast.ApiConnection.WeatherClasses

class Weather(var weather: List<WeatherDetail>, var main: WeatherMain, val sys: WeatherSys) {
}