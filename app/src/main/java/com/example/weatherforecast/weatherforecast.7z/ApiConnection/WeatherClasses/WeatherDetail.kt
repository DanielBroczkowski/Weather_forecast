package com.example.weatherforecast.ApiConnection.WeatherClasses

class WeatherDetail(var description: String) {
}