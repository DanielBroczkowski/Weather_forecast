package com.example.weatherforecast.ApiConnection.WeatherClasses

class WeatherMain(var temp: String, var pressure: String, var tempc: Float) {

    fun colorChange(): String{
        tempc = temp.toFloat() - 273.15f
        val color: String
        if (tempc > 20){
            color = "#ff0000"
        }
        else color = "#00ff00"

        return color
    }
}