package com.example.weatherforecast.ApiConnection.WeatherClasses

class WeatherSys(var sunrise: String, var sunset: String) {
}