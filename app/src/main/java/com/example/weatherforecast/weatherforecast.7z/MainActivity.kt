package com.example.weatherforecast

import android.graphics.Color
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.ArrayMap
import android.util.Log
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProvider
import com.example.weatherforecast.ApiConnection.SearchClasses.Search
import com.example.weatherforecast.ApiConnection.WeatherClasses.Weather
import kotlinx.android.synthetic.main.activity_main.*

class MainActivity : AppCompatActivity() {
    private lateinit var mainActivityViewModel: MainActivityViewModel


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val mainActivityViewModel =
            ViewModelProvider(this, ViewModelProvider.NewInstanceFactory()).get(
                MainActivityViewModel::class.java
            )



        searchImageButton.setOnClickListener {
            mainActivityViewModel.getWeather(cityEditText.text.toString())
        }

        mainActivityViewModel.getLiveData().observe(this, Observer { pressureTextView.text = it.main.pressure
            sunriseText.text = it.sys.sunrise
            sunsetText.text = it.sys.sunset
            colorChange(it.main.colorChange())
            temperatureTextView.text = it.main.tempc.toString()
        })


    }

    fun colorChange(color: String){

        toolbar.setBackgroundColor(Color.parseColor(color))
    }
}
